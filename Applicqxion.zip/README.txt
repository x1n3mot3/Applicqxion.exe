Applicqxion.exe
Made by x1n3mot3
This took me 2 hours to make
Destructive? yes for the harmful versions
Skidded? no
Arm version works? no gives a invalid character error
only test harmful version in a vm
if you are using my source code credit me
